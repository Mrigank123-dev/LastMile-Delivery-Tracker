import { NavLink, useNavigate } from 'react-router-dom';
import { clearSession } from '../api.js';

const NAV_BY_ROLE = {
  customer: [
    { to: '/orders/new', label: 'Place an Order' },
    { to: '/orders', label: 'My Orders' },
  ],
  agent: [
    { to: '/agent', label: 'My Deliveries' },
  ],
  admin: [
    { to: '/orders', label: 'All Orders' },
    { to: '/orders/new', label: 'Place an Order' },
    { to: '/admin/zones', label: 'Zones & Areas' },
    { to: '/admin/rates', label: 'Rate Cards' },
    { to: '/admin/agents', label: 'Agents' },
  ],
};

export default function Layout({ user, children }) {
  const navigate = useNavigate();

  function handleLogout() {
    clearSession();
    navigate('/login');
  }

  const links = NAV_BY_ROLE[user.role] || [];

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">Last-Mile<span className="dot">.</span></div>
        <div className="brand-sub">Delivery Tracker</div>
        <nav>
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}
              end={link.to === '/orders' || link.to === '/agent'}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div className="role-badge">{user.role}</div>
          <div>{user.name}</div>
          <div style={{ fontSize: 12 }}>{user.email}</div>
          <button className="logout-btn" onClick={handleLogout}>Log out</button>
        </div>
      </aside>
      <main className="main">{children}</main>
    </div>
  );
}
