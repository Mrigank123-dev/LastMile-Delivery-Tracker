import { useState } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { getSession } from './api.js';
import Layout from './components/Layout.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import PlaceOrder from './pages/PlaceOrder.jsx';
import OrderList from './pages/OrderList.jsx';
import OrderDetail from './pages/OrderDetail.jsx';
import AgentDashboard from './pages/AgentDashboard.jsx';
import AdminZones from './pages/AdminZones.jsx';
import AdminRateCards from './pages/AdminRateCards.jsx';
import AdminAgents from './pages/AdminAgents.jsx';

function Protected({ user, roles, children }) {
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />;
  return <Layout user={user}>{children}</Layout>;
}

export default function App() {
  const session = getSession();
  const [user, setUser] = useState(session?.user || null);

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login onAuth={setUser} />} />
      <Route path="/register" element={user ? <Navigate to="/" replace /> : <Register onAuth={setUser} />} />

      <Route path="/" element={
        user
          ? <Navigate to={user.role === 'agent' ? '/agent' : '/orders'} replace />
          : <Navigate to="/login" replace />
      } />

      <Route path="/orders/new" element={
        <Protected user={user} roles={['customer', 'admin']}><PlaceOrder user={user} /></Protected>
      } />
      <Route path="/orders" element={
        <Protected user={user} roles={['customer', 'admin']}><OrderList user={user} /></Protected>
      } />
      <Route path="/orders/:id" element={
        <Protected user={user}><OrderDetail user={user} /></Protected>
      } />
      <Route path="/agent" element={
        <Protected user={user} roles={['agent']}><AgentDashboard user={user} /></Protected>
      } />
      <Route path="/admin/zones" element={
        <Protected user={user} roles={['admin']}><AdminZones /></Protected>
      } />
      <Route path="/admin/rates" element={
        <Protected user={user} roles={['admin']}><AdminRateCards /></Protected>
      } />
      <Route path="/admin/agents" element={
        <Protected user={user} roles={['admin']}><AdminAgents /></Protected>
      } />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
